# GitHub Profile Analyzer API

A production-ready Node.js + Express backend that fetches public GitHub profile data, derives useful insights, and persists everything in MySQL.

---

## Features

| Feature | Details |
|---|---|
| **Profile Analysis** | Fetches user profile + up to 500 public repos |
| **Rich Insights** | Stars, forks, languages, topics, repo quality, account age, completeness score |
| **MySQL Storage** | Upsert on re-analysis, full history snapshots |
| **REST API** | List, search, single fetch, history, delete, stats |
| **Rate Limiting** | Per-IP limits via `express-rate-limit` |
| **Security** | `helmet`, `cors` |
| **Logging** | `morgan` (dev + production modes) |

---

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MySQL 8+ (via `mysql2`)
- **Third-party API**: GitHub REST API v3
- **Other**: axios, dotenv, helmet, cors, morgan, express-rate-limit

---

## Project Structure

```
github-analyzer/
├── index.js                        # Entry point
├── .env.example                    # Environment template
├── sql/
│   └── schema.sql                  # DB schema (run once)
└── src/
    ├── config/
    │   └── database.js             # MySQL connection pool
    ├── services/
    │   └── githubService.js        # GitHub API + insights derivation
    ├── models/
    │   └── profileModel.js         # All DB read/write operations
    ├── controllers/
    │   └── profileController.js    # Route handlers / business logic
    ├── routes/
    │   └── profileRoutes.js        # Express router
    └── middleware/
        └── errorHandler.js         # Global error handler
```

---

## Quick Start

### 1. Clone & Install

```bash
git clone <repo-url>
cd github-analyzer
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your MySQL credentials and (optional) GitHub token
```

### 3. Initialize MySQL Database

```bash
# Option A – npm script (set DB_USER / DB_PASSWORD in shell first)
npm run db:init

# Option B – direct
mysql -u root -p < sql/schema.sql
```

### 4. Start the Server

```bash
npm run dev     # development (nodemon)
npm start       # production
```

Server starts at `http://localhost:3000`.

---

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `PORT` | No | `3000` | Server port |
| `NODE_ENV` | No | `development` | `development` / `production` |
| `DB_HOST` | Yes | `localhost` | MySQL host |
| `DB_PORT` | No | `3306` | MySQL port |
| `DB_USER` | Yes | — | MySQL user |
| `DB_PASSWORD` | Yes | — | MySQL password |
| `DB_NAME` | No | `github_analyzer` | Database name |
| `GITHUB_TOKEN` | Recommended | — | Personal access token (raises rate limit from 60 → 5000 req/hr) |
| `RATE_LIMIT_WINDOW_MS` | No | `900000` | Rate-limit window (ms) |
| `RATE_LIMIT_MAX` | No | `100` | Max requests per window per IP |

---

## API Reference

### Base URL: `http://localhost:3000`

---

### `POST /api/profiles/analyze`

Fetch a GitHub user's profile and store/update insights in MySQL.

**Request Body**
```json
{ "username": "torvalds" }
```

**Response `200`**
```json
{
  "success": true,
  "message": "Profile for \"torvalds\" analyzed and stored successfully.",
  "data": { ...full profile object... }
}
```

---

### `GET /api/profiles`

List all analyzed profiles (paginated).

**Query Parameters**
| Param | Default | Description |
|---|---|---|
| `page` | `1` | Page number |
| `limit` | `20` | Results per page (max 100) |
| `search` | — | Filter by username substring |

**Response `200`**
```json
{
  "success": true,
  "total": 42,
  "page": 1,
  "limit": 20,
  "total_pages": 3,
  "profiles": [ ...summary objects... ]
}
```

---

### `GET /api/profiles/:username`

Fetch the full stored analysis for a single user.

**Response `200`**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "username": "torvalds",
    "display_name": "Linus Torvalds",
    "public_repos": 8,
    "followers": 240000,
    "total_stars_received": 190000,
    "primary_language": "C",
    "languages_used": ["C", "Python", "Shell"],
    "top_repos": [...],
    "profile_completeness_pct": 87,
    "account_age_days": 5200,
    "analyzed_at": "2025-01-01T12:00:00Z",
    ...
  }
}
```

---

### `GET /api/profiles/:username/history`

Returns timestamps of all past analyses for a user.

**Query Parameters**
| Param | Default | Description |
|---|---|---|
| `limit` | `10` | Max history entries (max 50) |

---

### `DELETE /api/profiles/:username`

Removes a profile and all its history from the database.

**Response `200`**
```json
{ "success": true, "message": "Profile \"torvalds\" deleted." }
```

---

### `GET /api/profiles/stats`

Aggregate statistics across all stored profiles.

**Response `200`**
```json
{
  "success": true,
  "data": {
    "total_profiles": 25,
    "total_stars": 500000,
    "avg_followers": 3200.5,
    "avg_repos": 42.1,
    "avg_completeness": 68.4,
    "last_analyzed_at": "2025-01-01T12:00:00Z"
  }
}
```

---

## Stored Insights

### Profile Fields
| Field | Description |
|---|---|
| `username` | GitHub login |
| `github_id` | GitHub numeric user ID |
| `display_name` / `bio` / `location` | Profile info |
| `account_type` | `User` or `Organization` |
| `public_repos` / `public_gists` | Public content counts |
| `followers` / `following` | Social graph |

### Derived Insights
| Field | Description |
|---|---|
| `follower_following_ratio` | followers ÷ following |
| `profile_completeness_pct` | % of profile fields filled (0–100) |
| `account_age_days` | Days since account creation |
| `has_blog` / `has_company` | Boolean completeness flags |

### Repository Aggregates (from all public repos)
| Field | Description |
|---|---|
| `total_stars_received` | Sum of all repo stars |
| `total_forks_received` | Sum of all repo forks |
| `total_open_issues` | Sum of open issues |
| `primary_language` | Most-used programming language |
| `languages_used` | JSON array of all languages (sorted) |
| `top_repos` | JSON array of top-5 repos by stars |
| `topics_used` | JSON array of all unique repo topics |
| `avg_repo_size_kb` | Average repo size |
| `repos_with_description` | Repos that have a description |
| `repos_with_topics` | Repos that have topics tagged |
| `repos_updated_last_year` | Active repos in last 12 months |

---

## Error Handling

| HTTP Status | Meaning |
|---|---|
| `400` | Missing / invalid request body |
| `404` | GitHub user or stored profile not found |
| `429` | GitHub API rate limit hit |
| `500` | Internal server error |
| `502` | GitHub API upstream error |
