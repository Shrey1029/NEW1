'use strict';

require('dotenv').config();

const express        = require('express');
const helmet         = require('helmet');
const cors           = require('cors');
const morgan         = require('morgan');
const rateLimit      = require('express-rate-limit');

const { testConnection } = require('./src/config/database');
const profileRoutes      = require('./src/routes/profileRoutes');
const errorHandler       = require('./src/middleware/errorHandler');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Security & Utility Middleware ────────────────────────────────────────────
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ─── Rate Limiting ────────────────────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      Number(process.env.RATE_LIMIT_MAX)        || 100,
  standardHeaders: true,
  legacyHeaders:   false,
  message: { success: false, message: 'Too many requests, please try again later.' },
});
app.use('/api/', limiter);

// ─── Routes ───────────────────────────────────────────────────────────────────
app.get('/', (_req, res) => {
  res.json({
    service: 'GitHub Profile Analyzer',
    version: '1.0.0',
    docs:    'See README.md for full API documentation',
    endpoints: {
      analyze:        'POST   /api/profiles/analyze',
      list:           'GET    /api/profiles',
      single:         'GET    /api/profiles/:username',
      history:        'GET    /api/profiles/:username/history',
      delete:         'DELETE /api/profiles/:username',
      stats:          'GET    /api/profiles/stats',
    },
  });
});

app.use('/api/profiles', profileRoutes);

// 404 handler
app.use((_req, res) => {
  res.status(404).json({ success: false, message: 'Route not found.' });
});

// Global error handler (must be last)
app.use(errorHandler);

// ─── Boot ─────────────────────────────────────────────────────────────────────
async function start() {
  try {
    await testConnection();
    app.listen(PORT, () => {
      console.log(`🚀  GitHub Analyzer API running on http://localhost:${PORT}`);
      console.log(`📄  Environment: ${process.env.NODE_ENV || 'development'}`);
    });
  } catch (err) {
    console.error('❌  Failed to start server:', err.message);
    process.exit(1);
  }
}

start();

module.exports = app; // for testing
