-- GitHub Analyzer Database Schema
-- Run this file to initialize the database

CREATE DATABASE IF NOT EXISTS github_analyzer
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE github_analyzer;

-- Core profile snapshot table
CREATE TABLE IF NOT EXISTS github_profiles (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username        VARCHAR(100)  NOT NULL,
  github_id       BIGINT        NOT NULL,
  display_name    VARCHAR(255),
  bio             TEXT,
  avatar_url      VARCHAR(500),
  profile_url     VARCHAR(500),
  company         VARCHAR(255),
  blog            VARCHAR(500),
  location        VARCHAR(255),
  email           VARCHAR(255),
  twitter_handle  VARCHAR(100),
  account_type    ENUM('User','Organization') DEFAULT 'User',

  -- Core counts
  public_repos    INT UNSIGNED  DEFAULT 0,
  public_gists    INT UNSIGNED  DEFAULT 0,
  followers       INT UNSIGNED  DEFAULT 0,
  following       INT UNSIGNED  DEFAULT 0,

  -- Derived insights
  follower_following_ratio  DECIMAL(10,4)  DEFAULT 0.0000,
  has_blog                  TINYINT(1)     DEFAULT 0,
  has_company               TINYINT(1)     DEFAULT 0,
  profile_completeness_pct  TINYINT UNSIGNED DEFAULT 0,  -- 0-100

  -- Repo-level aggregated insights (populated by deep analysis)
  total_stars_received    INT UNSIGNED DEFAULT 0,
  total_forks_received    INT UNSIGNED DEFAULT 0,
  total_watchers          INT UNSIGNED DEFAULT 0,
  total_open_issues       INT UNSIGNED DEFAULT 0,
  primary_language        VARCHAR(100),
  languages_used          JSON,          -- ["JavaScript","Python",...]
  top_repos               JSON,          -- [{name,stars,forks,language,url}]
  topics_used             JSON,          -- aggregated repo topics
  avg_repo_size_kb        INT UNSIGNED DEFAULT 0,
  repos_with_description  INT UNSIGNED DEFAULT 0,
  repos_with_topics       INT UNSIGNED DEFAULT 0,
  repos_updated_last_year INT UNSIGNED DEFAULT 0,

  -- Account age / activity
  github_created_at       DATETIME,
  github_updated_at       DATETIME,
  account_age_days        INT UNSIGNED DEFAULT 0,

  -- Record housekeeping
  analyzed_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  -- One row per username; re-analysis updates the row
  UNIQUE KEY uq_username (username),
  INDEX idx_followers       (followers),
  INDEX idx_public_repos    (public_repos),
  INDEX idx_stars           (total_stars_received),
  INDEX idx_analyzed_at     (analyzed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Analysis history: every time a profile is re-analyzed we keep a snapshot
CREATE TABLE IF NOT EXISTS analysis_history (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_id      INT UNSIGNED NOT NULL,
  username        VARCHAR(100) NOT NULL,
  snapshot        JSON         NOT NULL,   -- full profile JSON at time of analysis
  analyzed_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (profile_id) REFERENCES github_profiles(id) ON DELETE CASCADE,
  INDEX idx_profile_history (profile_id, analyzed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
