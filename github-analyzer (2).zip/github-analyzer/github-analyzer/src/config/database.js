'use strict';

const mysql = require('mysql2/promise');

let pool;

/**
 * Returns (and lazily creates) the shared connection pool.
 */
function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host:               process.env.DB_HOST     || 'localhost',
      port:               Number(process.env.DB_PORT) || 3306,
      user:               process.env.DB_USER     || 'root',
      password:           process.env.DB_PASSWORD || '',
      database:           process.env.DB_NAME     || 'github_analyzer',
      waitForConnections: true,
      connectionLimit:    10,
      queueLimit:         0,
      timezone:           'Z',
      decimalNumbers:     true,
    });
  }
  return pool;
}

/**
 * Verifies the DB is reachable – call once at startup.
 */
async function testConnection() {
  const conn = await getPool().getConnection();
  await conn.ping();
  conn.release();
  console.log('✅  MySQL connected successfully');
}

module.exports = { getPool, testConnection };
