'use strict';

const { analyzeGitHubUser } = require('../services/githubService');
const profileModel           = require('../models/profileModel');

// ─── Analyze & store ──────────────────────────────────────────────────────────

/**
 * POST /api/profiles/analyze
 * Body: { username: "torvalds" }
 *
 * Fetches from GitHub, upserts into MySQL, saves history snapshot.
 */
async function analyzeProfile(req, res) {
  const { username } = req.body;

  if (!username || typeof username !== 'string' || !username.trim()) {
    return res.status(400).json({ success: false, message: 'username is required' });
  }

  const cleanUsername = username.trim().toLowerCase();

  try {
    // 1. Fetch from GitHub
    const insights = await analyzeGitHubUser(cleanUsername);

    // 2. Upsert into DB
    const profileId = await profileModel.upsertProfile(insights);

    // 3. Save history snapshot
    await profileModel.saveHistory(profileId, cleanUsername, insights);

    // 4. Return the stored row
    const stored = await profileModel.getProfileById(profileId);

    return res.status(200).json({
      success: true,
      message: `Profile for "${cleanUsername}" analyzed and stored successfully.`,
      data: stored,
    });
  } catch (err) {
    if (err.response?.status === 404) {
      return res.status(404).json({ success: false, message: `GitHub user "${cleanUsername}" not found.` });
    }
    if (err.response?.status === 403) {
      return res.status(429).json({ success: false, message: 'GitHub API rate limit exceeded. Set GITHUB_TOKEN to increase it.' });
    }
    throw err; // caught by global error handler
  }
}

// ─── List all profiles ────────────────────────────────────────────────────────

/**
 * GET /api/profiles
 * Query: ?page=1&limit=20&search=torvalds
 */
async function listProfiles(req, res) {
  const page   = Math.max(1, parseInt(req.query.page,  10) || 1);
  const limit  = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
  const search = (req.query.search || '').trim();

  const result = await profileModel.listProfiles({ page, limit, search });

  return res.json({
    success: true,
    ...result,
    total_pages: Math.ceil(result.total / limit),
  });
}

// ─── Single profile by username ───────────────────────────────────────────────

/**
 * GET /api/profiles/:username
 */
async function getProfile(req, res) {
  const username = req.params.username.trim().toLowerCase();
  const profile  = await profileModel.getProfileByUsername(username);

  if (!profile) {
    return res.status(404).json({
      success: false,
      message: `Profile "${username}" not found. Use POST /api/profiles/analyze to analyze it first.`,
    });
  }

  return res.json({ success: true, data: profile });
}

// ─── Analysis history for a username ─────────────────────────────────────────

/**
 * GET /api/profiles/:username/history
 */
async function getProfileHistory(req, res) {
  const username = req.params.username.trim().toLowerCase();
  const limit    = Math.min(50, parseInt(req.query.limit, 10) || 10);

  // Ensure the profile exists
  const profile = await profileModel.getProfileByUsername(username);
  if (!profile) {
    return res.status(404).json({ success: false, message: `Profile "${username}" not found.` });
  }

  const history = await profileModel.getHistoryByUsername(username, limit);
  return res.json({ success: true, username, total: history.length, history });
}

// ─── Delete a profile ─────────────────────────────────────────────────────────

/**
 * DELETE /api/profiles/:username
 */
async function deleteProfile(req, res) {
  const username = req.params.username.trim().toLowerCase();
  const deleted  = await profileModel.deleteProfile(username);

  if (!deleted) {
    return res.status(404).json({ success: false, message: `Profile "${username}" not found.` });
  }

  return res.json({ success: true, message: `Profile "${username}" deleted.` });
}

// ─── Stats ────────────────────────────────────────────────────────────────────

/**
 * GET /api/profiles/stats
 */
async function getStats(req, res) {
  const stats = await profileModel.getStats();
  return res.json({ success: true, data: stats });
}

module.exports = {
  analyzeProfile,
  listProfiles,
  getProfile,
  getProfileHistory,
  deleteProfile,
  getStats,
};
