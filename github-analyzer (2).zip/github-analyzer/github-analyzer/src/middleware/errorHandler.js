'use strict';

/**
 * Centralised error-handling middleware.
 * Must be registered AFTER all routes.
 */
function errorHandler(err, req, res, _next) {
  // Axios / GitHub API errors
  if (err.response) {
    const status = err.response.status;
    const message =
      err.response.data?.message ||
      err.response.statusText    ||
      'GitHub API error';

    return res.status(status >= 500 ? 502 : status).json({
      success: false,
      message,
      source: 'github_api',
    });
  }

  // MySQL errors
  if (err.code && err.code.startsWith('ER_')) {
    console.error('[DB ERROR]', err.message);
    return res.status(500).json({
      success: false,
      message: 'Database error. Check server logs.',
      source: 'database',
    });
  }

  // Generic
  const status = err.status || err.statusCode || 500;
  console.error('[ERROR]', err.message);
  return res.status(status).json({
    success: false,
    message: err.message || 'Internal server error',
  });
}

module.exports = errorHandler;
