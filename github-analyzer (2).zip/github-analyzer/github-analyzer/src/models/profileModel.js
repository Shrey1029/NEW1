'use strict';

const { getPool } = require('../config/database');

// ─── Upsert ───────────────────────────────────────────────────────────────────

/**
 * Insert or update a profile row.
 * Returns the resulting row's `id`.
 */
async function upsertProfile(data) {
  const pool = getPool();

  const sql = `
    INSERT INTO github_profiles (
      username, github_id, display_name, bio, avatar_url, profile_url,
      company, blog, location, email, twitter_handle, account_type,
      public_repos, public_gists, followers, following,
      follower_following_ratio, has_blog, has_company, profile_completeness_pct,
      total_stars_received, total_forks_received, total_watchers, total_open_issues,
      primary_language, languages_used, top_repos, topics_used,
      avg_repo_size_kb, repos_with_description, repos_with_topics, repos_updated_last_year,
      github_created_at, github_updated_at, account_age_days,
      analyzed_at
    ) VALUES (
      :username, :github_id, :display_name, :bio, :avatar_url, :profile_url,
      :company, :blog, :location, :email, :twitter_handle, :account_type,
      :public_repos, :public_gists, :followers, :following,
      :follower_following_ratio, :has_blog, :has_company, :profile_completeness_pct,
      :total_stars_received, :total_forks_received, :total_watchers, :total_open_issues,
      :primary_language, :languages_used, :top_repos, :topics_used,
      :avg_repo_size_kb, :repos_with_description, :repos_with_topics, :repos_updated_last_year,
      :github_created_at, :github_updated_at, :account_age_days,
      NOW()
    )
    ON DUPLICATE KEY UPDATE
      github_id                 = VALUES(github_id),
      display_name              = VALUES(display_name),
      bio                       = VALUES(bio),
      avatar_url                = VALUES(avatar_url),
      profile_url               = VALUES(profile_url),
      company                   = VALUES(company),
      blog                      = VALUES(blog),
      location                  = VALUES(location),
      email                     = VALUES(email),
      twitter_handle            = VALUES(twitter_handle),
      account_type              = VALUES(account_type),
      public_repos              = VALUES(public_repos),
      public_gists              = VALUES(public_gists),
      followers                 = VALUES(followers),
      following                 = VALUES(following),
      follower_following_ratio  = VALUES(follower_following_ratio),
      has_blog                  = VALUES(has_blog),
      has_company               = VALUES(has_company),
      profile_completeness_pct  = VALUES(profile_completeness_pct),
      total_stars_received      = VALUES(total_stars_received),
      total_forks_received      = VALUES(total_forks_received),
      total_watchers            = VALUES(total_watchers),
      total_open_issues         = VALUES(total_open_issues),
      primary_language          = VALUES(primary_language),
      languages_used            = VALUES(languages_used),
      top_repos                 = VALUES(top_repos),
      topics_used               = VALUES(topics_used),
      avg_repo_size_kb          = VALUES(avg_repo_size_kb),
      repos_with_description    = VALUES(repos_with_description),
      repos_with_topics         = VALUES(repos_with_topics),
      repos_updated_last_year   = VALUES(repos_updated_last_year),
      github_created_at         = VALUES(github_created_at),
      github_updated_at         = VALUES(github_updated_at),
      account_age_days          = VALUES(account_age_days),
      analyzed_at               = NOW()
  `;

  // mysql2 doesn't support named placeholders natively – convert to positional
  const fields = [
    'username','github_id','display_name','bio','avatar_url','profile_url',
    'company','blog','location','email','twitter_handle','account_type',
    'public_repos','public_gists','followers','following',
    'follower_following_ratio','has_blog','has_company','profile_completeness_pct',
    'total_stars_received','total_forks_received','total_watchers','total_open_issues',
    'primary_language','languages_used','top_repos','topics_used',
    'avg_repo_size_kb','repos_with_description','repos_with_topics','repos_updated_last_year',
    'github_created_at','github_updated_at','account_age_days',
  ];

  // Build positional query
  const positionalSql = sql.replace(/:([a-z_]+)/g, '?');
  const values = fields.map(f => data[f] !== undefined ? data[f] : null);

  const [result] = await pool.execute(positionalSql, values);

  // insertId is 0 on UPDATE; fetch the real id
  if (result.insertId) return result.insertId;
  const [[row]] = await pool.execute(
    'SELECT id FROM github_profiles WHERE username = ?', [data.username]
  );
  return row.id;
}

/**
 * Saves a history snapshot after every analysis.
 */
async function saveHistory(profileId, username, snapshot) {
  const pool = getPool();
  await pool.execute(
    'INSERT INTO analysis_history (profile_id, username, snapshot) VALUES (?, ?, ?)',
    [profileId, username, JSON.stringify(snapshot)]
  );
}

// ─── Queries ──────────────────────────────────────────────────────────────────

/**
 * Paginated list of all analyzed profiles.
 * Supports optional search by username.
 */
async function listProfiles({ page = 1, limit = 20, search = '' } = {}) {
  const pool   = getPool();
  const offset = (page - 1) * limit;

  const whereClause = search ? 'WHERE username LIKE ?' : '';
  const searchParam = search ? [`%${search}%`] : [];

  const [[{ total }]] = await pool.execute(
    `SELECT COUNT(*) AS total FROM github_profiles ${whereClause}`,
    searchParam
  );

  const [rows] = await pool.execute(
    `SELECT
       id, username, display_name, avatar_url, profile_url,
       public_repos, followers, following,
       total_stars_received, primary_language,
       profile_completeness_pct, account_age_days,
       analyzed_at
     FROM github_profiles
     ${whereClause}
     ORDER BY analyzed_at DESC
     LIMIT ? OFFSET ?`,
    [...searchParam, limit, offset]
  );

  return { total, page, limit, profiles: rows };
}

/**
 * Full profile by username.
 */
async function getProfileByUsername(username) {
  const pool = getPool();
  const [[row]] = await pool.execute(
    'SELECT * FROM github_profiles WHERE username = ?',
    [username]
  );
  return row || null;
}

/**
 * Full profile by internal id.
 */
async function getProfileById(id) {
  const pool = getPool();
  const [[row]] = await pool.execute(
    'SELECT * FROM github_profiles WHERE id = ?',
    [id]
  );
  return row || null;
}

/**
 * Analysis history for a username (most recent first).
 */
async function getHistoryByUsername(username, limit = 10) {
  const pool = getPool();
  const [rows] = await pool.execute(
    'SELECT id, analyzed_at FROM analysis_history WHERE username = ? ORDER BY analyzed_at DESC LIMIT ?',
    [username, limit]
  );
  return rows;
}

/**
 * Delete a profile and its history.
 */
async function deleteProfile(username) {
  const pool = getPool();
  const [result] = await pool.execute(
    'DELETE FROM github_profiles WHERE username = ?',
    [username]
  );
  return result.affectedRows > 0;
}

/**
 * Quick DB stats for the /stats endpoint.
 */
async function getStats() {
  const pool = getPool();
  const [[row]] = await pool.execute(`
    SELECT
      COUNT(*)                          AS total_profiles,
      SUM(total_stars_received)         AS total_stars,
      AVG(followers)                    AS avg_followers,
      AVG(public_repos)                 AS avg_repos,
      AVG(profile_completeness_pct)     AS avg_completeness,
      MAX(analyzed_at)                  AS last_analyzed_at
    FROM github_profiles
  `);
  return row;
}

module.exports = {
  upsertProfile,
  saveHistory,
  listProfiles,
  getProfileByUsername,
  getProfileById,
  getHistoryByUsername,
  deleteProfile,
  getStats,
};
