'use strict';

const { Router }       = require('express');
const profileController = require('../controllers/profileController');

const router = Router();

// ── Analyze (create/refresh) ────────────────────────────────────────
// POST /api/profiles/analyze
// Body: { "username": "torvalds" }
router.post('/analyze', profileController.analyzeProfile);

// ── Stats (must come before /:username to avoid route collision) ────
// GET /api/profiles/stats
router.get('/stats', profileController.getStats);

// ── List all ────────────────────────────────────────────────────────
// GET /api/profiles?page=1&limit=20&search=linus
router.get('/', profileController.listProfiles);

// ── Single profile ──────────────────────────────────────────────────
// GET /api/profiles/:username
router.get('/:username', profileController.getProfile);

// ── Analysis history ────────────────────────────────────────────────
// GET /api/profiles/:username/history?limit=10
router.get('/:username/history', profileController.getProfileHistory);

// ── Delete ──────────────────────────────────────────────────────────
// DELETE /api/profiles/:username
router.delete('/:username', profileController.deleteProfile);

module.exports = router;
