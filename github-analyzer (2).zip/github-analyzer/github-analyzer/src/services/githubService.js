'use strict';

const axios = require('axios');

// ─── Axios instance ───────────────────────────────────────────────────────────
const github = axios.create({
  baseURL: 'https://api.github.com',
  timeout: 10_000,
  headers: {
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    ...(process.env.GITHUB_TOKEN && {
      Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
    }),
  },
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function daysBetween(dateStr) {
  if (!dateStr) return 0;
  return Math.floor((Date.now() - new Date(dateStr).getTime()) / 86_400_000);
}

function profileCompletenessScore(user) {
  const fields = [
    user.name, user.bio, user.company, user.blog,
    user.location, user.email, user.twitter_username, user.avatar_url,
  ];
  const filled = fields.filter(Boolean).length;
  return Math.round((filled / fields.length) * 100);
}

// ─── Fetch up to 5 pages of repos (max 500) ──────────────────────────────────
async function fetchAllRepos(username) {
  const repos = [];
  for (let page = 1; page <= 5; page++) {
    const { data } = await github.get(`/users/${username}/repos`, {
      params: { per_page: 100, page, sort: 'updated', type: 'owner' },
    });
    repos.push(...data);
    if (data.length < 100) break;
  }
  return repos;
}

// ─── Derive repo-level insights ───────────────────────────────────────────────
function aggregateRepoInsights(repos) {
  const oneYearAgo = Date.now() - 365 * 86_400_000;

  let totalStars = 0, totalForks = 0, totalWatchers = 0, totalOpenIssues = 0;
  let totalSizeKb = 0, reposWithDesc = 0, reposWithTopics = 0, recentlyUpdated = 0;

  const langCount = {};
  const topicSet  = new Set();

  for (const r of repos) {
    totalStars      += r.stargazers_count  || 0;
    totalForks      += r.forks_count       || 0;
    totalWatchers   += r.watchers_count    || 0;
    totalOpenIssues += r.open_issues_count || 0;
    totalSizeKb     += r.size              || 0;

    if (r.description)                       reposWithDesc++;
    if (r.topics && r.topics.length)         reposWithTopics++;
    if (new Date(r.updated_at) > oneYearAgo) recentlyUpdated++;
    if (r.language)                          langCount[r.language] = (langCount[r.language] || 0) + 1;
    (r.topics || []).forEach(t => topicSet.add(t));
  }

  // Top 5 repos by stars
  const topRepos = [...repos]
    .sort((a, b) => b.stargazers_count - a.stargazers_count)
    .slice(0, 5)
    .map(r => ({
      name:     r.name,
      stars:    r.stargazers_count,
      forks:    r.forks_count,
      language: r.language,
      url:      r.html_url,
      description: r.description,
    }));

  // Languages sorted by usage
  const languagesSorted = Object.entries(langCount)
    .sort(([, a], [, b]) => b - a)
    .map(([lang]) => lang);

  return {
    total_stars_received:    totalStars,
    total_forks_received:    totalForks,
    total_watchers:          totalWatchers,
    total_open_issues:       totalOpenIssues,
    primary_language:        languagesSorted[0] || null,
    languages_used:          JSON.stringify(languagesSorted),
    top_repos:               JSON.stringify(topRepos),
    topics_used:             JSON.stringify([...topicSet]),
    avg_repo_size_kb:        repos.length ? Math.round(totalSizeKb / repos.length) : 0,
    repos_with_description:  reposWithDesc,
    repos_with_topics:       reposWithTopics,
    repos_updated_last_year: recentlyUpdated,
  };
}

// ─── Main export ──────────────────────────────────────────────────────────────

/**
 * Fetches a GitHub user's public profile + repo insights.
 * Returns a flat object ready to be upserted into MySQL.
 *
 * @param {string} username
 * @returns {Promise<Object>}
 */
async function analyzeGitHubUser(username) {
  // 1. Public profile
  const { data: user } = await github.get(`/users/${username}`);

  // 2. Public repos (for aggregation)
  const repos = user.public_repos > 0 ? await fetchAllRepos(username) : [];

  // 3. Repo-level insights
  const repoInsights = aggregateRepoInsights(repos);

  // 4. Derived profile fields
  const followerFollowingRatio =
    user.following > 0
      ? parseFloat((user.followers / user.following).toFixed(4))
      : user.followers;   // treat as raw count when following = 0

  return {
    username:                   user.login,
    github_id:                  user.id,
    display_name:               user.name       || null,
    bio:                        user.bio        || null,
    avatar_url:                 user.avatar_url || null,
    profile_url:                user.html_url   || null,
    company:                    user.company    || null,
    blog:                       user.blog       || null,
    location:                   user.location   || null,
    email:                      user.email      || null,
    twitter_handle:             user.twitter_username || null,
    account_type:               user.type       || 'User',

    public_repos:               user.public_repos  || 0,
    public_gists:               user.public_gists  || 0,
    followers:                  user.followers     || 0,
    following:                  user.following     || 0,

    follower_following_ratio:   followerFollowingRatio,
    has_blog:                   user.blog ? 1 : 0,
    has_company:                user.company ? 1 : 0,
    profile_completeness_pct:   profileCompletenessScore(user),

    github_created_at:          user.created_at ? new Date(user.created_at) : null,
    github_updated_at:          user.updated_at ? new Date(user.updated_at) : null,
    account_age_days:           daysBetween(user.created_at),

    ...repoInsights,
  };
}

module.exports = { analyzeGitHubUser };
